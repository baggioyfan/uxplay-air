#!/bin/bash
cd "$(dirname "$0")" || exit 1
export DYLD_LIBRARY_PATH="$PWD/lib"
export GST_PLUGIN_PATH_1_0="$PWD/gstreamer-1.0"
export GST_PLUGIN_SYSTEM_PATH_1_0=""
export GST_REGISTRY_1_0="$PWD/.gst-registry.bin"
[ -x "$PWD/libexec/gst-plugin-scanner" ] && export GST_PLUGIN_SCANNER="$PWD/libexec/gst-plugin-scanner"
exec "$PWD/bin/uxplay" -vsync no "$@"
